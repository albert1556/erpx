from django.apps import AppConfig


class XfndConfig(AppConfig):
    name = 'xfnd'
